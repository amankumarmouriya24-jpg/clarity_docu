from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from flask import Response, jsonify, render_template_string, request, send_from_directory


ROOT_DIR = Path(__file__).resolve().parent
BACKEND_DIR = ROOT_DIR / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from config import Config  # type: ignore  # noqa: E402
from services.database_service import DatabaseService  # type: ignore  # noqa: E402
from services.extractor_service import ExtractorService  # type: ignore  # noqa: E402
from services.simplifier_service import SimplifierService  # type: ignore  # noqa: E402


def _load_backend_app():
    """Load the Flask application from backend/app.py without name collision."""
    backend_app_path = BACKEND_DIR / "app.py"
    spec = importlib.util.spec_from_file_location("claritydoc_backend_app", backend_app_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load backend Flask app")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.app


def _render_dashboard():
    """Render the shared ClarityDoc dashboard frontend."""
    template = (ROOT_DIR / "index.html").read_text(encoding="utf-8")
    return render_template_string(template, documents=[])


app = _load_backend_app()


@app.get("/")
def index():
    """Render the ClarityDoc dashboard."""
    return _render_dashboard()


@app.get("/upload")
def upload():
    """Render the document processing dashboard."""
    return _render_dashboard()


@app.post("/process-text")
def process_text():
    """Process pasted text through the same local extraction pipeline."""
    payload = request.get_json(silent=True) or {}
    raw_text = str(payload.get("text", "")).strip()
    if not raw_text:
        return jsonify({"success": False, "error": "Text input is required"}), 400

    extracted = ExtractorService.extract_information(raw_text)
    simplified_result = SimplifierService.simplify_document(raw_text, extracted)
    document = DatabaseService.create_document_with_result(
        filename="pasted-text.txt",
        filepath="text-input",
        raw_text=raw_text,
        document_type=extracted["document_type"],
        summary="\n".join(simplified_result["easy_explanation"]),
        action_required=simplified_result["action_required"],
        deadline=simplified_result["deadline"],
        contact=simplified_result["contact"],
        amount_due=simplified_result["amount_due"],
        priority=simplified_result["priority"],
    )

    return jsonify(
        {
            "success": True,
            "message": "Text processed successfully",
            "document": document.to_dict(),
            "result": simplified_result,
            "extracted_information": extracted,
        }
    ), 201


@app.get("/result/<int:document_id>")
def result(document_id: int):
    """Return a saved document result as JSON."""
    client = app.test_client()
    response = client.get(f"/document/{document_id}")
    return Response(response.get_data(), status=response.status_code, mimetype="application/json")


@app.get("/static/css/style.css")
def root_style():
    """Serve the root frontend stylesheet expected by index.html."""
    return send_from_directory(ROOT_DIR, "style.css")


@app.get("/static/js/script.js")
def root_script():
    """Serve the root frontend script expected by index.html."""
    return send_from_directory(ROOT_DIR, "script.js")


if __name__ == "__main__":
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
