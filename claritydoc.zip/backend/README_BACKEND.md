# ClarityDoc Backend

This is the complete Flask backend for ClarityDoc, an offline document simplification assistant for medical, insurance, government, banking, legal, electricity, and water documents.

## Features

- Upload PDF, PNG, JPG, and JPEG files
- Validate extension, MIME type, file size, and empty uploads
- Save files in `uploads/`
- Extract text locally using Tesseract OCR
- Convert PDF pages to images using `pdf2image`
- Fall back to embedded PDF text extraction using `PyPDF2`
- Simplify complex document language with offline rules
- Extract document type, action, deadline, contact, amount, and priority
- Store documents and processed results in SQLite
- Return JSON responses for frontend integration
- Log API requests, uploads, OCR errors, and database errors

## Folder Structure

```text
backend/
  app.py
  config.py
  extensions.py
  database.py
  models.py
  routes.py
  requirements.txt
  .env.example
  services/
    ocr_service.py
    simplifier_service.py
    extractor_service.py
    database_service.py
  utils/
    helpers.py
    validators.py
  uploads/
  database/
  instance/
```

## Setup

```bash
cd backend
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Install system tools for OCR:

```bash
brew install tesseract poppler
```

On Linux:

```bash
sudo apt-get install tesseract-ocr poppler-utils
```

## Run

```bash
cd backend
python app.py
```

The API starts at:

```text
http://127.0.0.1:5000
```

## API Endpoints

### GET `/health`

Returns backend status.

Response:

```json
{
  "status": "running"
}
```

### POST `/upload`

Accepts one uploaded file with form field name `file`.

Example:

```bash
curl -X POST http://127.0.0.1:5000/upload \
  -F "file=@sample.pdf"
```

Response:

```json
{
  "success": true,
  "message": "Document processed successfully",
  "document": {
    "id": 1,
    "filename": "sample_1710000000_abcd123456.pdf",
    "filepath": "/path/to/backend/uploads/sample_1710000000_abcd123456.pdf",
    "upload_time": "2026-06-28T10:00:00+00:00",
    "raw_text": "OCR text...",
    "document_type": "Insurance Policy",
    "processed_result": {
      "id": 1,
      "document_id": 1,
      "summary": "Simplified text...",
      "action_required": "Submit the required document",
      "deadline": "15 July 2026",
      "contact": "1800-111-222, support@example.com",
      "amount_due": "Rs. 2,500",
      "priority": "High"
    }
  }
}
```

### GET `/documents`

Returns all processed documents.

### GET `/document/<id>`

Returns one document and its processed result.

### DELETE `/document/<id>`

Deletes the database record and uploaded file.

## SQLite Tables

### `documents`

- `id`
- `filename`
- `filepath`
- `upload_time`
- `raw_text`
- `document_type`

### `processed_results`

- `id`
- `document_id`
- `summary`
- `action_required`
- `deadline`
- `contact`
- `amount_due`
- `priority`

## Notes for Frontend Developers

- Use `multipart/form-data` for `/upload`.
- The upload field name must be `file`.
- CORS is enabled.
- All errors return JSON with `success: false` and an `error` message.
- The backend is independent and can be run without the frontend.
